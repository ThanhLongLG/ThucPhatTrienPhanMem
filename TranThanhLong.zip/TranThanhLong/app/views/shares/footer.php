<footer class="bg-light text-center text-lg-start mt-4">
    <div class="container p-4">
    <div class="row">
    <!-- Cột thông tin liên hệ -->
    <div class="col-lg-6 col-md-12 mb-4">
        <h5 class="text-uppercase">Quản lý sản phẩm</h5>
        <p>
            Hệ thống quản lý sản phẩm giúp bạn theo dõi và cập nhật thông tin
            sản phẩm dễ dàng.
        </p>
    </div>
    <!-- Cột liên kết nhanh -->
    <div class="col-lg-3 col-md-6 mb-4">
        <h5 class="text-uppercase">Liên kết nhanh</h5>
        <ul class="list-unstyled mb-0">
        <li><a href="/webbanhang/Product/" class="text-dark">Danh sách sản
        phẩm</a></li>
        <li><a href="/webbanhang/Product/add" class="text-dark">Thêm sản
        phẩm</a></li>
        </ul>
    </div>
    <!-- Cột mạng xã hội -->
    <div class="col-lg-3 col-md-6 mb-4">
    <footer class="bg-light text-center text-lg-start mt-4">
    <div class="container p-4">
    <div class="row">
    <!-- Cột thông tin liên hệ -->
    <div class="col-lg-6 col-md-12 mb-4">
    <h5 class="text-uppercase">Quản lý sản phẩm</h5>
    <p>
        Hệ thống quản lý sản phẩm giúp bạn theo dõi và cập nhật thông tin
        sản phẩm dễ dàng.
    </p>
    </div>
<!-- Cột liên kết nhanh -->
    <div class="col-lg-3 col-md-6 mb-4">
    <h5 class="text-uppercase">Liên kết nhanh</h5>
    <ul class="list-unstyled mb-0">
        <li><a href="/TranThanhLong/Product/" class="text-dark">Danh sách sản
        phẩm</a></li>
        <li><a href="/TranThanhLong/Product/add" class="text-dark">Thêm sản
        phẩm</a></li>
    </ul>
    </div>
    <!-- Cột mạng xã hội -->
    <div class="col-lg-3 col-md-6 mb-4">