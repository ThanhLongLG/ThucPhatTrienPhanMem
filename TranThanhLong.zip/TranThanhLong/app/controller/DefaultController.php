<?php
    class DefaultController{
        public function index(){
            echo 'Hello World';
        }

    }
?>